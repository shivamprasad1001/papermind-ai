import * as express from 'express';
import { parsePdf, chunkText } from '../services/pdfService';
import { embedChunks, getEmbeddings } from '../services/geminiService';
import { upsertToPinecone, queryPinecone } from '../services/pineconeService';
import { getChatCompletion } from '../services/geminiService';
import { initPinecone } from '../services/pineconeService';
import { addMessageToHistory, getHistory } from '../services/chatHistoryService';

// Initialize Pinecone client at startup
let pineconeClient: any;
(async () => {
    try {
        pineconeClient = await initPinecone();
        console.log('Pinecone initialized successfully.');
    } catch (error) {
        console.error('Pinecone initialization failed:', error);
        (process as any).exit(1);
    }
})();

interface RequestWithFile extends express.Request {
    file?: Express.Multer.File;
}

export const uploadAndProcessPdf = async (req: RequestWithFile, res: express.Response, next: express.NextFunction) => {
    if (!req.file) {
        return res.status(400).json({ message: 'No file uploaded.' });
    }

    try {
        const docId = `doc-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
        
        console.log(`Processing document: ${req.file.originalname}, ID: ${docId}`);

        // 1. Parse PDF
        const text = await parsePdf(req.file.buffer);
        console.log(`PDF parsed, ${text.length} characters.`);

        // 2. Chunk Text
        const chunks = chunkText(text);
        console.log(`Text chunked into ${chunks.length} parts.`);

        // 3. Embed Chunks
        const embeddings = await embedChunks(chunks);
        console.log('Chunks embedded successfully.');

        // 4. Upsert to Pinecone
        await upsertToPinecone(pineconeClient, embeddings, chunks, docId);
        console.log('Embeddings upserted to Pinecone.');
        
        res.status(201).json({ 
            message: 'File uploaded and processed successfully.',
            document: {
                id: docId,
                name: req.file.originalname
            }
        });
    } catch (error) {
        console.error('Error in file upload and processing:', error);
        next(error);
    }
};

export const chatWithDocument = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const { message, documentId, userType = 'general' } = req.body;

    if (!message || !documentId) {
        return res.status(400).json({ message: 'Message and documentId are required.' });
    }

    // Validate user type
    const validUserTypes = ['student', 'teacher', 'researcher', 'general'];
    const validatedUserType = validUserTypes.includes(userType) ? userType : 'general';

    try {
        // 1. Get relevant context from Pinecone
        const queryEmbedding = await getEmbeddings(message);
        const contextChunks = await queryPinecone(pineconeClient, queryEmbedding, documentId);
        const context = contextChunks.map(chunk => chunk.metadata?.text || '').filter(Boolean).join('\n\n');
        
        // 2. Get chat history
        const history = getHistory(documentId);

        // 3. Add user message to history
        addMessageToHistory(documentId, { role: 'user', parts: [{ text: message }] });

        // 4. Set up headers for streaming
        res.setHeader('Content-Type', 'text/event-stream');
        res.setHeader('Cache-Control', 'no-cache');
        res.setHeader('Connection', 'keep-alive');
        res.flushHeaders();

        // 5. Get streaming response from Gemini
        const stream = await getChatCompletion(message, context, history, validatedUserType);
        
        let fullResponse = '';
        for await (const chunk of stream) {
            const textPart = chunk.text;
            if (textPart) {
                fullResponse += textPart;
                res.write(textPart);
            }
        }

        // 6. Add AI response to history
        addMessageToHistory(documentId, { role: 'model', parts: [{ text: fullResponse }] });

        res.end();

    } catch (error) {
        console.error('Error in chat processing:', error);
        next(error);
    }
};