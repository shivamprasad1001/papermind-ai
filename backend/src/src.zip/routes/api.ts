
import express from 'express';
import multer from 'multer';
import { uploadAndProcessPdf, chatWithDocument } from '../controllers/chatController';

const router = express.Router();

// Configure multer for file uploads
const storage = multer.memoryStorage();
const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024, // 10 MB limit
    }
});

router.post('/upload', upload.single('file'), uploadAndProcessPdf);
router.post('/chat', chatWithDocument);

export default router;
