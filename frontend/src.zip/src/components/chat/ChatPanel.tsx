import React, { useEffect, useRef, useState } from 'react';
import { useChat } from '../../hooks/useChat'; // Your custom hook for chat logic
import { useAppContext } from '../../context/AppContext';
import Message from './Message'; // Your component for rendering a single, complete message
import MessageInput from './MessageInput';
import UserTypeSelector from '../common/UserTypeSelector';
import QuickActions from '../common/QuickActions';
import type { MessageType } from '../../types'; // Your main message type definition
import { BrainCircuitIcon } from '../common/icons'; // Icon for the AI avatar

const ChatPanel = () => {
  // Your useChat hook must provide these states and setters
  const { messages, setMessages, isStreaming, activeDocumentId, documents } = useChat();
  const { state: appState } = useAppContext();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // KEY STATE: This holds the text for the AI response that is currently streaming in.
  // This state is separate from the main `messages` array.
  const [streamingText, setStreamingText] = useState<string>('');
  
  const activeDocument = documents.find(d => d.id === activeDocumentId);

  // --- IMPORTANT ---
  // The logic to handle SSE events should live inside your `useChat` hook.
  // When your `sendMessage` function in `useChat` receives events, it should call:
  // - `setStreamingText(prev => prev + payload)` for 'token' events.
  // - `setMessages(prev => [...prev, payload])` and `setStreamingText('')` for the 'complete' event.
  // This useEffect is a placeholder to show how that logic would look.
  useEffect(() => {
    // This is where your EventSource listener would be.
    // In a real implementation, this logic is inside the `useChat` hook and is not in a useEffect here.
    const handleSseMessage = (event: MessageEvent) => {
      
      
      const dataChunk = event.data;
      // Your backend sends multiple `data: {}` chunks in one go. We need to parse them.
      dataChunk.split('\ndata: ').forEach((chunk: string) => {
        if (!chunk.trim().startsWith('data:')) {
          chunk = 'data: ' + chunk;
        }
        const jsonString = chunk.replace(/^data: /, '');
        console.log(jsonString);
        
        if (jsonString) {
          try {
            const parsed = JSON.parse(jsonString);
            console.log("parsed");
            
            console.log(parsed.payload);
            
            if (parsed.type === 'token') {
              setStreamingText(prev => prev + parsed.payload);
            } else if (parsed.type === 'complete') {
              setMessages((prev: MessageType[]) => [...prev, parsed.payload]);
              setStreamingText('');
              // useChat hook would set isStreaming(false) here
            }
          } catch (e) {
            console.error("Failed to parse SSE chunk:", jsonString, e);
          }
        }
      });
    };
    // Example: sseConnection.onmessage = handleSseMessage;
  }, [setMessages]); // Dependency array shows what this logic depends on.

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Scroll down when new final messages arrive or when new text is streamed.
  useEffect(() => {
    scrollToBottom();
  }, [messages, streamingText]);

  // This function handles the API call when a user clicks the like/dislike buttons.
  const handleFeedback = async (messageId: string, feedback: 'like' | 'dislike') => {
    // Optimistically update the UI for a responsive feel
    setMessages((prevMessages: MessageType[]) =>
      prevMessages.map(msg =>
        msg.messageId === messageId ? { ...msg, feedback: feedback } : msg
      )
    );

    // Send the feedback to your backend
    try {
      const response = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ documentId: activeDocumentId, messageId, feedback }),
      });
      if (!response.ok) throw new Error('API call failed');
    } catch (error) {
      console.error('Failed to submit feedback:', error);
      // If the API call fails, revert the change in the UI
      setMessages((prevMessages: MessageType[]) =>
        prevMessages.map(msg =>
          msg.messageId === messageId ? { ...msg, feedback: undefined } : msg
        )
      );
    }
  };

  return (
    <div className="flex flex-col h-full max-h-screen">
      <header className="p-4 border-b border-[var(--bg-border)] bg-[var(--bg-header)] backdrop-blur-sm z-10 flex-shrink-0">
        <div className="flex items-center justify-between">
            {/* Your Header Content */}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        {activeDocument && <QuickActions />}
        <div className="p-4 md:p-6 space-y-6">
          
          {/* 1. RENDER ALL FINAL, COMPLETE MESSAGES */}
          {messages.map((msg: MessageType) => (
            <Message
              key={msg.messageId}
              message={msg}
              onFeedback={handleFeedback}
            />
          ))}

          {/* 2. RENDER THE LIVE, STREAMING AI RESPONSE (TEMPORARY) */}
          {isStreaming && streamingText && (
            <div className={`flex items-start gap-3 w-full justify-start`}>
              <div className="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-primary/30">
                <BrainCircuitIcon className="w-5 h-5 text-primary" />
              </div>
              <div className="max-w-xl lg:max-w-3xl px-4 py-3 rounded-2xl prose prose-sm prose-invert dark:prose-invert max-w-none bg-[var(--aiMessage)] text-gray-200 self-start rounded-bl-lg border border-[var(--aiMessage-border)] backdrop-blur-lg">
                {streamingText}
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="p-4 border-t border-transparent flex-shrink-0 bg-transparent">
        <MessageInput />
      </div>
    </div>
  );
};

export default ChatPanel;


// import React, { useEffect, useRef } from 'react';
// import { useChat } from '../../hooks/useChat';
// import { useAppContext } from '../../context/AppContext';
// import Message from './Message';
// import MessageInput from './MessageInput';
// import TypingIndicator from './TypingIndicator';
// import UserTypeSelector from '../common/UserTypeSelector';
// import QuickActions from '../common/QuickActions';

// const ChatPanel = () => {
//   const { messages, isStreaming, activeDocumentId, documents } = useChat();
//   const { state } = useAppContext();
//   const messagesEndRef = useRef<HTMLDivElement>(null);
  
//   const activeDocument = documents.find(d => d.id === activeDocumentId);

//   const scrollToBottom = () => {
//     messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
//   };

//   useEffect(() => {
//     scrollToBottom();
//   }, [messages, isStreaming]);

//   return (
//     <div className="flex flex-col h-full max-h-screen">
//       <header className="p-4 border-b border-[var(--bg-border)] bg-[var(--bg-header)] backdrop-blur-sm z-10 flex-shrink-0">
//         <div className="flex items-center justify-between">
//           <div className="flex items-center space-x-3">
//             <h2 className="text-lg font-semibold text-[var(--text-primary)] truncate">
//               {activeDocument ? <>Chatting with: <span className="text-[var(--bg-button)]">{activeDocument.name}</span></> : "No Document Selected"}
//             </h2>
//             {activeDocument && (
//               <div className="flex items-center space-x-2 px-2 py-1 bg-[var(--bg-surface)] rounded-full">
//                 <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
//                 <span className="text-xs text-[var(--text-secondary)] font-medium">
//                   {state.userType.charAt(0).toUpperCase() + state.userType.slice(1)} Mode
//                 </span>
//               </div>
//             )}
//           </div>
//           {activeDocument && <UserTypeSelector />}
//         </div>
//       </header>

//       <div className="flex-1 overflow-y-auto">
//         {activeDocument && <QuickActions />}
//         <div className="p-4 md:p-6 space-y-6">
//           {messages.map((msg) => (
//             <Message key={msg.id} message={msg} />
//           ))}
//           {isStreaming && <TypingIndicator />}
//           <div ref={messagesEndRef} />
//         </div>
//       </div>

//       <div className="p-4 border-t border-transparent  flex-shrink-0 bg-transparent">
//         <MessageInput />
//       </div>
//     </div>
//   );
// };

// export default ChatPanel;
